GWOSC Internal Portal
=====================

The GWOSC integration for CBCFlow is currently in an alpha form, and has not yet been reviewed. 
It may be accessed through the GWOSC catalog portal, when logged in with LVK credentials (https://gwosc-rl8.ligo.caltech.edu/eventapi/html/).
The current testing instance is ``cbcflow.alpha``, and reflects only certain test data.
When further integration has occurred, this will be updated to reflect real use cases.