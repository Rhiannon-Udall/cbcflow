Asimov Integration
==================

