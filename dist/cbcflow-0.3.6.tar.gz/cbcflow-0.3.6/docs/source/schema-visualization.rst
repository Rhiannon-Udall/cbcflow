Schema Breakdown
================

.. raw:: html
    :file: schema_visualization/cbc-meta-data-schema.html